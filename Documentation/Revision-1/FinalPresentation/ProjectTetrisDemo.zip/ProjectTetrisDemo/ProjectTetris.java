
import javax.swing.JPanel;


public class ProjectTetris extends JPanel {

	public static void main(String[] args) {
		new TetrisController();
	}

}
